
package GestorProductos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class GestorProductos {
      // Relación de composición 1 -- 0..* con Producto (según el diagrama)
    private ArrayList<Producto> productos;

    public GestorProductos() {
        this.productos = new ArrayList<Producto>();
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
        System.out.println("Producto agregado: " + producto);
    }

    
    public void mostrarProductos() {
        if (productos.isEmpty()) {
            System.out.println("No hay productos registrados.");
            return;
        }
        System.out.println("----- Lista de productos -----");
        for (Producto p : productos) {
            System.out.println(p);
        }
        System.out.println("Total de productos: " + productos.size());
    }

   
    public boolean actualizarProducto(int id, double nuevoPrecio) {
        for (Producto p : productos) {
            if (p.getId() == id) {
                p.setPrecio(nuevoPrecio);
                System.out.println("Producto actualizado: " + p);
                return true;
            }
        }
        System.out.println("No se encontro un producto con id " + id);
        return false;
    }

    
    public boolean eliminarProducto(int id) {
        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).getId() == id) {
                Producto eliminado = productos.remove(i);
                System.out.println("Producto eliminado: " + eliminado);
                return true;
            }
        }
        System.out.println("No se encontró un producto con id " + id);
        return false;
    }

    
    public void ordenarPorPrecio() {
        Collections.sort(productos, new Comparator<Producto>() {
            @Override
            public int compare(Producto p1, Producto p2) {
                return Double.compare(p1.getPrecio(), p2.getPrecio());
            }
        });
        System.out.println("Productos ordenados por precio.");
    }
    
}
