
package GestorProductos;

public class Main {
     public static void main(String[] args) {

        GestorProductos gestor = new GestorProductos();

        
        gestor.agregarProducto(new Producto(1, "Teclado mecanico", 150000));
        gestor.agregarProducto(new Producto(2, "Mouse inalambrico", 65000));
        gestor.agregarProducto(new Producto(3, "Monitor 24 pulgadas", 620000));

        
        gestor.mostrarProductos();

       
        gestor.actualizarProducto(2, 59900);

     
        gestor.actualizarProducto(99, 10000);

   
        gestor.eliminarProducto(1);

       
        gestor.ordenarPorPrecio();
        gestor.mostrarProductos();
    }
    
}
